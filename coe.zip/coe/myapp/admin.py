from django.contrib import admin
from myapp.models import Details
# Register your models here.
admin.site.register(Details)