from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [
    path('', views.index, name="home"),
    path('my_account', views.my_account, name="my_account"),
    path('avail_job', views.avail_job, name="avail_job"),
    path('my_applied', views.my_applied, name="my_applied"),
    path('my_announced', views.my_announced, name="my_announced"),
]