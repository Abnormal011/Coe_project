#pip install pyresparser
#pip install spacy==2.3.5
#pip install https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-2.3.1/en_core_web_sm-2.3.1.tar.gz
#python -m spacy download en_core_web_sm

#Run the above lines in terminal window

#Scoring System
import nltk
nltk.download('stopwords')

from pyresparser import ResumeParser
import os
import nltk

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity


skills = 'skills.pdf'
resume = 'Jeet.pdf'

data = ResumeParser(skills).get_extracted_data()

def Score(resume):
    data2 = ResumeParser(resume).get_extracted_data()

    required_skills = str(data['skills'])
    candidate_skills = str(data2['skills'])

    content = [required_skills,candidate_skills]

    cv = CountVectorizer()
    matrix = cv.fit_transform(content)

    similarity_matrix = cosine_similarity(matrix)

    #print(similarity_matrix)
    return similarity_matrix[1][0]*100

"""
This program will be able to store the score of each candidate/apllier's score in the database.
If we want to make some improvements in this website we can add too many things and make it so that we can email the selected employees that they are selected, as well as recruiter will get a list of the selected employees and they can schedule the physical interview using this website too.
"""

"""
In this prototype we are only taking applicants for 1 job but if we want we can make it so that different recruiters will be able to announce jobs on the website.
"""