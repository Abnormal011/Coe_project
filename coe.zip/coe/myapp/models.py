from django.db import models
from datetime import datetime
from myapp import score

# Create your models here.
class Details(models.Model):
    email = models.CharField(max_length=50)
    fname = models.CharField(max_length=122)
    lname = models.CharField(max_length=122)
    birthdate = models.DateField()
    number = models.PositiveIntegerField()
    education = models.TextChoices
    experience = models.IntegerChoices
    resume = models.FileField()
    score = score(resume)

def __str__(self):
    self.name = self.fname + "_" + self.lname
    return self.name