from django.shortcuts import render, redirect
from myapp.models import Details
from django.contrib import messages
from datetime import datetime, timezone
from myapp import score

# Create your views here.
def index(request):
    if request.method == "POST":
        email = request.POST.get('email')
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        number = request.POST.get('number')
        birthdate = request.POST.get('birthdate')
        education = request.POST.get('education')
        experience = request.POST.get('to_year') - request.POST.get('from_year')
        resume = request.POST.get('resume')
        index = Details(email = email, fname = fname, lname = lname, birthdate = birthdate, number = number, education = education, experience = experience , resume = resume, score = score())
        index.save()

    if index.objects.filter(email=email).exists():
        messages.error(request, "Email Already Registered!!")
        return redirect('home')

    messages.success(request, "Your Account has been created succesfully!! Please check your email to confirm your email address in order to activate your account.")

def my_account(request):
    return render(request, 'my_account.html')

def avail_job(request):
    return render(request, 'avail_job.html')

def my_applied(request):
    return render(request, 'my_applied.html')

def my_announced(request):
    return render(request, 'my_announced.html')